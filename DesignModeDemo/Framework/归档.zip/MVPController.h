//
//  MVPController.h
//  DesignModeDemo
//
//  Created by JimmyZhao on 2017/6/14.
//  Copyright © 2017年 bihu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MVPController : UIViewController

@end
