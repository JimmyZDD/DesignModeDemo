//
//  MVPModel.m
//  DesignModeDemo
//
//  Created by JimmyZhao on 2017/6/14.
//  Copyright © 2017年 bihu. All rights reserved.
//

#import "MVPModel.h"

@implementation MVPModel

@end
